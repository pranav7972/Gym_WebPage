import { ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'
import { Loader2 } from 'lucide-react'

interface ProtectedRouteProps {
  children: ReactNode
  requiredRole?: 'user' | 'admin'
  requiredTier?: 'free' | 'pro' | 'premium'
}

export default function ProtectedRoute({ 
  children, 
  requiredRole = 'user',
  requiredTier 
}: ProtectedRouteProps) {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary-500" />
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/auth" replace />
  }

  // Check role requirements
  if (requiredRole === 'admin' && user.role !== 'admin') {
    return <Navigate to="/dashboard" replace />
  }

  // Check tier requirements
  if (requiredTier) {
    const tierLevels = { free: 0, pro: 1, premium: 2 }
    const userTierLevel = tierLevels[user.membership_tier]
    const requiredTierLevel = tierLevels[requiredTier]
    
    if (userTierLevel < requiredTierLevel) {
      return <Navigate to="/dashboard?upgrade=true" replace />
    }
  }

  return <>{children}</>
}