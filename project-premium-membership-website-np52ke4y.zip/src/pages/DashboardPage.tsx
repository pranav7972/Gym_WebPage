import { Crown, BookOpen, Users, TrendingUp, Star } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Badge } from '../components/ui/badge'
import { useAuth } from '../hooks/useAuth'
import { Link } from 'react-router-dom'

export default function DashboardPage() {
  const { user } = useAuth()

  const getTierColor = (tier: string) => {
    switch (tier) {
      case 'premium': return 'bg-gradient-to-r from-yellow-400 to-orange-500'
      case 'pro': return 'bg-gradient-to-r from-blue-400 to-blue-600'
      default: return 'bg-gradient-to-r from-gray-400 to-gray-600'
    }
  }

  const getTierBenefits = (tier: string) => {
    switch (tier) {
      case 'premium':
        return ['All premium content', 'Exclusive masterclasses', '1-on-1 consultations', 'Early access']
      case 'pro':
        return ['Premium articles', 'Member webinars', 'Priority support', 'Advanced features']
      default:
        return ['Basic content', 'Community access', 'Email support']
    }
  }

  const recentContent = [
    { id: 1, title: 'Advanced React Patterns', type: 'Article', tier: 'pro', readTime: '15 min' },
    { id: 2, title: 'Building Scalable APIs', type: 'Tutorial', tier: 'premium', readTime: '45 min' },
    { id: 3, title: 'Design System Best Practices', type: 'Guide', tier: 'free', readTime: '20 min' },
  ]

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-serif font-bold text-gradient mb-2">
            Welcome back, {user?.email}
          </h1>
          <p className="text-muted-foreground">
            Here's what's happening in your premium community today.
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="premium-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Membership</CardTitle>
              <Crown className="h-4 w-4 text-primary-500" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-2">
                <Badge className={`${getTierColor(user?.membership_tier || 'free')} text-white capitalize`}>
                  {user?.membership_tier}
                </Badge>
                {user?.membership_tier === 'free' && (
                  <Button variant="outline" size="sm" asChild>
                    <Link to="/auth">Upgrade</Link>
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="premium-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Content Read</CardTitle>
              <BookOpen className="h-4 w-4 text-primary-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24</div>
              <p className="text-xs text-muted-foreground">
                +12% from last month
              </p>
            </CardContent>
          </Card>

          <Card className="premium-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Community</CardTitle>
              <Users className="h-4 w-4 text-primary-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,247</div>
              <p className="text-xs text-muted-foreground">
                Active members
              </p>
            </CardContent>
          </Card>

          <Card className="premium-card">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Progress</CardTitle>
              <TrendingUp className="h-4 w-4 text-primary-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">89%</div>
              <p className="text-xs text-muted-foreground">
                Course completion
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Recent Content */}
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BookOpen className="h-5 w-5 mr-2 text-primary-500" />
                  Continue Learning
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentContent.map((content) => (
                    <div key={content.id} className="flex items-center justify-between p-4 glass rounded-lg">
                      <div className="flex-1">
                        <h3 className="font-semibold">{content.title}</h3>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {content.type}
                          </Badge>
                          <Badge 
                            variant="outline" 
                            className={`text-xs ${
                              content.tier === 'premium' ? 'border-yellow-500 text-yellow-500' :
                              content.tier === 'pro' ? 'border-blue-500 text-blue-500' :
                              'border-gray-500 text-gray-500'
                            }`}
                          >
                            {content.tier}
                          </Badge>
                          <span className="text-xs text-muted-foreground">{content.readTime}</span>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" asChild>
                        <Link to={`/content/${content.id}`}>
                          Continue
                        </Link>
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="premium-card">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2" asChild>
                    <Link to="/content">
                      <BookOpen className="h-6 w-6" />
                      <span>Browse Content</span>
                    </Link>
                  </Button>
                  <Button variant="outline" className="h-20 flex flex-col items-center justify-center space-y-2">
                    <Users className="h-6 w-6" />
                    <span>Community</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Membership Benefits */}
            <Card className="premium-card">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="h-5 w-5 mr-2 text-primary-500" />
                  Your Benefits
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {getTierBenefits(user?.membership_tier || 'free').map((benefit, index) => (
                    <li key={index} className="flex items-center text-sm">
                      <div className="w-2 h-2 bg-primary-500 rounded-full mr-3" />
                      {benefit}
                    </li>
                  ))}
                </ul>
                {user?.membership_tier === 'free' && (
                  <Button className="w-full mt-4 cta-button" asChild>
                    <Link to="/auth">Upgrade Now</Link>
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Community Highlights */}
            <Card className="premium-card">
              <CardHeader>
                <CardTitle>Community Highlights</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-sm">
                    <p className="font-semibold">New Masterclass</p>
                    <p className="text-muted-foreground">Advanced TypeScript Patterns</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-semibold">Member Spotlight</p>
                    <p className="text-muted-foreground">Sarah J. shares her success story</p>
                  </div>
                  <div className="text-sm">
                    <p className="font-semibold">Upcoming Event</p>
                    <p className="text-muted-foreground">Live Q&A with industry experts</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}