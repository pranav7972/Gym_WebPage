import { useState } from 'react'
import { useParams } from 'react-router-dom'
import { Lock, Star, Filter, Search, Play } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Badge } from '../components/ui/badge'
import { Input } from '../components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select'
import { useAuth } from '../hooks/useAuth'
import { Link } from 'react-router-dom'

const mockContent = [
  {
    id: 1,
    title: 'Getting Started with React 18',
    description: 'Learn the fundamentals of React 18 including new features and best practices.',
    type: 'Article',
    tier: 'free',
    duration: '15 min read',
    author: 'John Smith',
    rating: 4.8,
    thumbnail: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=400&h=225&fit=crop',
    category: 'Frontend'
  },
  {
    id: 2,
    title: 'Advanced TypeScript Patterns',
    description: 'Master advanced TypeScript patterns for building scalable applications.',
    type: 'Tutorial',
    tier: 'pro',
    duration: '45 min',
    author: 'Sarah Davis',
    rating: 4.9,
    thumbnail: 'https://images.unsplash.com/photo-1516116216624-53e697fedbea?w=400&h=225&fit=crop',
    category: 'Development'
  },
  {
    id: 3,
    title: 'Building Scalable APIs',
    description: 'Complete guide to designing and implementing scalable REST APIs.',
    type: 'Masterclass',
    tier: 'premium',
    duration: '2 hours',
    author: 'Mike Johnson',
    rating: 5.0,
    thumbnail: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?w=400&h=225&fit=crop',
    category: 'Backend'
  },
  {
    id: 4,
    title: 'Design System Fundamentals',
    description: 'Learn how to create and maintain effective design systems.',
    type: 'Course',
    tier: 'pro',
    duration: '1.5 hours',
    author: 'Emma Wilson',
    rating: 4.7,
    thumbnail: 'https://images.unsplash.com/photo-1609921212029-bb5a28e60960?w=400&h=225&fit=crop',
    category: 'Design'
  }
]

export default function ContentPage() {
  const { contentId } = useParams()
  const { user } = useAuth()
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedTier, setSelectedTier] = useState('all')

  // If contentId is provided, show individual content
  if (contentId) {
    const content = mockContent.find(c => c.id === parseInt(contentId))
    if (!content) {
      return <div>Content not found</div>
    }

    const canAccess = checkAccess(content.tier, user?.membership_tier || 'free')

    return (
      <div className="min-h-screen py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {canAccess ? (
            <Card className="premium-card">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="mb-2">
                    {content.category}
                  </Badge>
                  <Badge className={getTierBadgeClass(content.tier)}>
                    {content.tier}
                  </Badge>
                </div>
                <CardTitle className="text-3xl font-serif">{content.title}</CardTitle>
                <p className="text-muted-foreground">{content.description}</p>
                <div className="flex items-center space-x-4 pt-4">
                  <span className="text-sm text-muted-foreground">By {content.author}</span>
                  <span className="text-sm text-muted-foreground">•</span>
                  <span className="text-sm text-muted-foreground">{content.duration}</span>
                  <span className="text-sm text-muted-foreground">•</span>
                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-500 mr-1" />
                    <span className="text-sm">{content.rating}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <img 
                  src={content.thumbnail} 
                  alt={content.title}
                  className="w-full h-64 object-cover rounded-lg mb-6"
                />
                <div className="prose prose-invert max-w-none">
                  <p>This is premium content that would normally be restricted based on membership tier. Since you have access, you can read the full article here.</p>
                  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="premium-card">
              <CardContent className="p-12 text-center">
                <Lock className="h-16 w-16 text-muted-foreground mx-auto mb-6" />
                <h2 className="text-2xl font-bold mb-4">Premium Content</h2>
                <p className="text-muted-foreground mb-6">
                  This content requires a {content.tier} membership to access.
                </p>
                <Button className="cta-button" asChild>
                  <Link to="/auth">Upgrade Your Membership</Link>
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    )
  }

  // Show content library
  const filteredContent = mockContent.filter(content => {
    const matchesSearch = content.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         content.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === 'all' || content.category.toLowerCase() === selectedCategory
    const matchesTier = selectedTier === 'all' || content.tier === selectedTier
    
    return matchesSearch && matchesCategory && matchesTier
  })

  return (
    <div className="min-h-screen py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-serif font-bold text-gradient mb-2">
            Content Library
          </h1>
          <p className="text-muted-foreground">
            Explore our curated collection of premium content and resources.
          </p>
        </div>

        {/* Filters */}
        <Card className="premium-card mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search content..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 glass"
                />
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="glass">
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="frontend">Frontend</SelectItem>
                  <SelectItem value="backend">Backend</SelectItem>
                  <SelectItem value="design">Design</SelectItem>
                  <SelectItem value="development">Development</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={selectedTier} onValueChange={setSelectedTier}>
                <SelectTrigger className="glass">
                  <SelectValue placeholder="Access Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="free">Free</SelectItem>
                  <SelectItem value="pro">Pro</SelectItem>
                  <SelectItem value="premium">Premium</SelectItem>
                </SelectContent>
              </Select>
              
              <Button variant="outline" className="glass">
                <Filter className="h-4 w-4 mr-2" />
                More Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredContent.map((content) => {
            const canAccess = checkAccess(content.tier, user?.membership_tier || 'free')
            
            return (
              <Card key={content.id} className="premium-card group">
                <div className="relative">
                  <img 
                    src={content.thumbnail} 
                    alt={content.title}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                  {content.type === 'Masterclass' && (
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-red-600 text-white">
                        <Play className="h-3 w-3 mr-1" />
                        Video
                      </Badge>
                    </div>
                  )}
                  <div className="absolute top-4 right-4">
                    <Badge className={getTierBadgeClass(content.tier)}>
                      {content.tier}
                    </Badge>
                  </div>
                  {!canAccess && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center rounded-t-lg">
                      <Lock className="h-8 w-8 text-white" />
                    </div>
                  )}
                </div>
                
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline">{content.category}</Badge>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 text-yellow-500 mr-1" />
                      <span className="text-sm">{content.rating}</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg group-hover:text-primary-500 transition-colors">
                    {content.title}
                  </CardTitle>
                  <p className="text-sm text-muted-foreground line-clamp-2">
                    {content.description}
                  </p>
                </CardHeader>
                
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-muted-foreground">
                      <p>By {content.author}</p>
                      <p>{content.duration}</p>
                    </div>
                    <Button 
                      variant={canAccess ? "default" : "outline"} 
                      size="sm"
                      asChild={canAccess}
                      disabled={!canAccess}
                    >
                      {canAccess ? (
                        <Link to={`/content/${content.id}`}>
                          Read Now
                        </Link>
                      ) : (
                        <>
                          <Lock className="h-4 w-4 mr-2" />
                          Locked
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </div>
  )
}

function checkAccess(contentTier: string, userTier: string): boolean {
  const tierLevels = { free: 0, pro: 1, premium: 2 }
  return tierLevels[userTier as keyof typeof tierLevels] >= tierLevels[contentTier as keyof typeof tierLevels]
}

function getTierBadgeClass(tier: string): string {
  switch (tier) {
    case 'premium': return 'bg-gradient-to-r from-yellow-400 to-orange-500 text-black'
    case 'pro': return 'bg-gradient-to-r from-blue-400 to-blue-600 text-white'
    default: return 'bg-gradient-to-r from-gray-400 to-gray-600 text-white'
  }
}