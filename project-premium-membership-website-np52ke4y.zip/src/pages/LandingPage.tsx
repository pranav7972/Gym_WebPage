import { Link } from 'react-router-dom'
import { Crown, Zap, Shield, Star, Check, ArrowRight } from 'lucide-react'
import { Button } from '../components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'

const features = [
  {
    icon: Crown,
    title: 'Premium Content',
    description: 'Access exclusive articles, tutorials, and resources from industry experts.'
  },
  {
    icon: Zap,
    title: 'Instant Access',
    description: 'Get immediate access to our entire library of premium content.'
  },
  {
    icon: Shield,
    title: 'Secure Platform',
    description: 'Your data and content are protected with enterprise-grade security.'
  },
  {
    icon: Star,
    title: 'Expert Community',
    description: 'Connect with professionals and thought leaders in your industry.'
  }
]

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: '/month',
    description: 'Perfect for getting started',
    features: [
      'Access to basic content',
      'Community forum access',
      'Email support',
      'Limited downloads'
    ],
    cta: 'Get Started',
    popular: false
  },
  {
    name: 'Pro',
    price: '$9',
    period: '/month',
    description: 'Most popular for professionals',
    features: [
      'All free features',
      'Premium articles & tutorials',
      'Advanced search & filters',
      'Priority support',
      'Unlimited downloads',
      'Member-only webinars'
    ],
    cta: 'Start Free Trial',
    popular: true
  },
  {
    name: 'Premium',
    price: '$19',
    period: '/month',
    description: 'For power users and teams',
    features: [
      'All Pro features',
      'Exclusive masterclasses',
      '1-on-1 expert consultations',
      'Early access to new content',
      'Custom content requests',
      'White-label solutions'
    ],
    cta: 'Contact Sales',
    popular: false
  }
]

export default function LandingPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-primary-900/20 via-transparent to-primary-800/20" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="animate-float mb-8">
              <Crown className="h-16 w-16 text-primary-500 mx-auto" />
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-gradient mb-6 animate-fade-in">
              Unlock Premium
              <br />
              Knowledge & Community
            </h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8 animate-slide-up">
              Join thousands of professionals accessing exclusive content, expert insights, 
              and a thriving community of industry leaders.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
              <Link to="/auth">
                <Button size="lg" className="cta-button text-lg px-8 py-4">
                  Start Your Journey
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link to="/content">
                <Button variant="outline" size="lg" className="text-lg px-8 py-4 glass border-primary-500/30 hover:bg-primary-500/10">
                  Explore Content
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gradient mb-4">
              Why Choose PremiumHub?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Experience the difference with our premium platform designed for success.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={feature.title} className="premium-card animate-slide-up" style={{ animationDelay: `${index * 0.1}s` }}>
                <CardHeader className="text-center">
                  <feature.icon className="h-12 w-12 text-primary-500 mx-auto mb-4" />
                  <CardTitle className="text-xl font-semibold">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-center">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gradient mb-4">
              Choose Your Plan
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Start free and upgrade as you grow. All plans include our core features.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {plans.map((plan, index) => (
              <Card 
                key={plan.name} 
                className={`premium-card relative ${
                  plan.popular ? 'ring-2 ring-primary-500 animate-glow' : ''
                }`}
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <span className="gold-gradient px-4 py-1 rounded-full text-sm font-semibold text-black">
                      Most Popular
                    </span>
                  </div>
                )}
                
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-gradient">{plan.price}</span>
                    <span className="text-muted-foreground">{plan.period}</span>
                  </div>
                  <p className="text-muted-foreground mt-2">{plan.description}</p>
                </CardHeader>
                
                <CardContent>
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-center">
                        <Check className="h-5 w-5 text-primary-500 mr-3 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Link to="/auth" className="block">
                    <Button 
                      className={`w-full ${
                        plan.popular 
                          ? 'cta-button' 
                          : 'bg-secondary hover:bg-secondary/80'
                      }`}
                      size="lg"
                    >
                      {plan.cta}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 lg:py-32">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Card className="premium-card">
            <CardContent className="p-12">
              <h2 className="text-3xl lg:text-4xl font-serif font-bold text-gradient mb-6">
                Ready to Elevate Your Game?
              </h2>
              <p className="text-xl text-muted-foreground mb-8">
                Join thousands of professionals who've already transformed their careers with PremiumHub.
              </p>
              <Link to="/auth">
                <Button size="lg" className="cta-button text-lg px-8 py-4">
                  Start Your Free Trial Today
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}