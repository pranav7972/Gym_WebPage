import { createContext, useContext, useEffect, useState, ReactNode } from 'react'

// For now, we'll use mock authentication until Supabase is connected
interface User {
  id: string
  email: string
  role: 'user' | 'admin'
  membership_tier: 'free' | 'pro' | 'premium'
}

interface AuthContextType {
  user: User | null
  loading: boolean
  signIn: (email: string, password: string) => Promise<void>
  signUp: (email: string, password: string) => Promise<void>
  signOut: () => void
}

const AuthContext = createContext<AuthContextType | null>(null)

// Mock authentication for now
const mockUsers: Record<string, User> = {
  'demo@example.com': {
    id: '1',
    email: 'demo@example.com',
    role: 'user',
    membership_tier: 'pro'
  },
  'admin@example.com': {
    id: '2',
    email: 'admin@example.com',
    role: 'admin',
    membership_tier: 'premium'
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check for stored user session
    const storedUser = localStorage.getItem('auth-user')
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setLoading(false)
  }, [])

  const signIn = async (email: string, password: string) => {
    setLoading(true)
    
    // Mock authentication
    if (mockUsers[email] && password === 'password') {
      const user = mockUsers[email]
      setUser(user)
      localStorage.setItem('auth-user', JSON.stringify(user))
    } else {
      throw new Error('Invalid credentials')
    }
    
    setLoading(false)
  }

  const signUp = async (email: string) => {
    setLoading(true)
    
    // Mock sign up - create new user with free tier
    const newUser: User = {
      id: Date.now().toString(),
      email,
      role: 'user',
      membership_tier: 'free'
    }
    
    mockUsers[email] = newUser
    setUser(newUser)
    localStorage.setItem('auth-user', JSON.stringify(newUser))
    
    setLoading(false)
  }

  const signOut = () => {
    setUser(null)
    localStorage.removeItem('auth-user')
  }

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      signIn,
      signUp,
      signOut
    }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}